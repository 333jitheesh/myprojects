import { Component, OnInit } from '@angular/core';
declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-footer-adminsession',
  templateUrl: './footer-adminsession.component.html',
  styleUrls: ['./footer-adminsession.component.css']
})
export class FooterAdminsessionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    

    
  }

}
