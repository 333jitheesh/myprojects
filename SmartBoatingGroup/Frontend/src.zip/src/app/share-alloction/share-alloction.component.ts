import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-alloction',
  templateUrl: './share-alloction.component.html',
  styleUrls: ['./share-alloction.component.css']
})
export class ShareAlloctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
