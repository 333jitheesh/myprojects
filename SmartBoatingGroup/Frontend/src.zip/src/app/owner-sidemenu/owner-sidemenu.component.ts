import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-owner-sidemenu',
  templateUrl: './owner-sidemenu.component.html',
  styleUrls: ['./owner-sidemenu.component.css']
})
export class OwnerSidemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
